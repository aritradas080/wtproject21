<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            margin:0;
            padding:0;
            font-family: arial;

        }

        .container{
            position: absolute;
            Left:0;
            Top:0;
            width:100%;
            height:100vh;
            animation: animate 16s ease-in-out infinite;
            background: rgba(0,0,0,0.5)
         }

         .outer{
            position: absolute;
            Left:0;
            Top:0;
            width:100%;
            height:100vh;
            animation: animate 16s ease-in-out infinite;
            background-size:cover; 
         }

         .details{
            position: absolute;
            Left:50%;
            Top:30%;
            transform: translate(-50%, -50%);
         }

         @keyframes animate{
 
             0%,100%{
                 background-image: url(r2.png);
             }
             50%{
                 background-image: url(c1.png);
             }
             75%{
                 background-image: url(c2.png);
             }
         }
    </style>
</head>
<body>

<?php
    if(isset($_SESSION["uname"])){
        session_start();
    }
?>

<div class="container">
      <div class="outer">
         <div class="details">
<h2 align="middle">Preferable choice : </h2>
<h3 align="center">Choose your interest : </h3>
<form action="" method="post">

        <button type="submit" formaction="hills.php">
            Go for Hills
        </button>
          
        <button type="submit" formaction="seabeaches.php">
            Go for Beaches
        </button>

        <button type="submit" formaction="historical.php">
            Go for Historical interests
        </button>
          
        <button type="submit" formaction="natural.php">
            Go for Natural beauties
        </button>
    </form>

</body>
</html>