<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br><br><br>
<p>Room Booked Successfully....<a href="../rooms.php">Click Here to go to main page.</a></p>
</body>
</html>