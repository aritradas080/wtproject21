<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body bgcolor="#ace5ee">
<?php
    if(isset($_SESSION["uname"])){
        session_start();
    }
?>
    <h1 align="middle">Welcome to Sundarbans</h1>
    <p align="center"><img src="MicrosoftTeams-image.png" height="250" width="300" alt="">
    <img src="MicrosoftTeams-image (1).png" height="250" width="300" alt=""></p>
    <h2 align="center">About Sundarbans</h2>
    <h4 align="center">The largest mangrove forest, Sundarbans, spans from the Hooghly River in India's state of West Bengal to the Baleshwar River in Bangladesh's division of Khulna. The unique wildlife, animals and eco-system is a sight to behold.</h4>
    <br>
    <h2 align="middle">You prefer : </h1>
    <form action="sundarbans.php" method="post">
        <div align="center"><input type="radio" id="night" name="media" value="night">
        <label for="night">Night Coach</label>
        <input type="radio" id="day" name="media" value="day">
        <label for="day">Day Coach</label>
        <br><br>
        <input type="submit" name ="submit"></div>
        <br>
   

    <?php
            if (isset($_POST["submit"])) 
             {
            $answer2 = $_POST['media'];


if ($answer2 == "night"){

        session_start();
        header("refresh: 1; url=Sun_media_night.php");
    }

if ($answer2 == "day"){
        session_start();
        header("refresh: 1; url=Sun_media_day.php");}


    }
?>
<b><a href="places.php">Back</a></b>
</form>

    </body>
</html>

