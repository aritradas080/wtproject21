<?php
if(session_status() >= 0){
    session_start();
    if(isset($_SESSION["uname"])){
        header("refresh: 1; url=private.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin</title>
</head>
<body bgcolor="Teal">
    <h1 align="middle" style="color:#FFFFFF">Welcome Admin</h1>
    <form action="adminloginprocess.php" method="post">
        <center>
    <h5></h5>
    <div><input type="text" name="uname" placeholder="Username"></div>
    <br><br>
    <div><input type="password" name="pass" placeholder="Password"></div>
    <br><br>
    <input type="submit" name="submit"><br>
</center>
 
</body>
</html>

