<?php
if(session_status() >= 0){
    if(isset($_SESSION["uname"])){
        header("refresh: 0.5; url=private.php");
    }
}

if(isset($_POST["submit"])){
    $uname=$_POST["uname"];
    $id=$_POST["id"];


$conn=mysqli_connect('localhost', 'root','', 'app_users');
$sql="SELECT *FROM travel_details WHERE username ='$uname' and id='$id'";

$result = mysqli_query($conn,$sql);
$row= mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if($count==1){
    session_start();

    $_SESSION["uname"]=$uname;

    echo "You are now redirected";
    header("refresh: 2; url=departure.php");
    exit();

}

else{
    echo "User not found.";
    header("refresh: 2; url=places.php");
    exit();

}
}

if(!isset($_POST["submit"])){
    echo "Complete your choices"."<br>";
    header("refresh: 2; url=places.php");

}
?>