<?php
$dbhost = 'localhost';
$dbname = 'app_users';
$dbusername = 'root';
$dbpass= '';
$conn = mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);

?>