<!DOCTYPE html>
<html lang="en">
<head>
    <title>Rangamati</title>
</head>
<body bgcolor="#ffccbb">
<h1 align="middle">Welcome to Rangamati</h1>
    <p align="center"><img src="r1.png" height="250" width="300" alt="">
    <img src="r2.png" height="250" width="300" alt=""></p>
    <h2 align="center">About Rangamati</h2>
    <h4 align="center">Rangamati is located 77 kilometers away from Chittagong through narrow roads. The town is located on the western bank of Kaptai lake. Rangamati is one of the most popular tourists stops for having so many tourist attractions. Form Sajek Vally to Kaptai Lake, Rangamati is full of beautiful green hills and rivers.</h4>
    <br>

    <h2 align="middle">You prefer : </h1>
    <form action="rangamati.php" method="post">
        <div align="center"><input type="radio" id="night" name="media" value="night">
        <label for="night">Night Coach</label>
        <input type="radio" id="day" name="media" value="day">
        <label for="day">Day Coach</label>
        <br><br>
        <input type="submit" name ="submit"></div>
        <br>


        <?php
            if (isset($_POST["submit"])) 
             {
            $answer4 = $_POST['media'];


if ($answer4 == "night"){

        session_start();
        header("refresh: 1; url=Ran_media_night.php");
    }

if ($answer4 == "day"){
        session_start();
        header("refresh: 1; url=Ran_media_day.php");}


    }
?>
    <a href="places.php">Back</a>
</body>
</html>