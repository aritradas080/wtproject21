<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br><br><br>
<p>Guide Booked Successfully....<a href="../sguides.php">Click Here to go to main page.</a></p>
</body>
</html>