<?php
session_start();
$server="localhost";
$username="root";
$password="";
$dbname="app_users";

$conn=mysqli_connect($server, $username, $password, $dbname);

if(isset($_POST['submit'])){
// echo "fff";
  if(!empty($_POST['s_no']) && !empty($_POST['id'])){
      // echo "fff";
      if($_POST['id']>1005){
          // echo "fff";
      $answer1=$_POST['s_no'];
      $answer2=$_POST['id'];
      
      
      $query="INSERT INTO sguide(s_no, id, holder_name, holder_mobile, status) VALUES ('$answer1', '$answer2','NULL', 'NULL', 0)";
      $run=mysqli_query($conn,$query);
      if($run){
          echo "Guide Slot added successfully";
          header("refresh:2; url=sguides.php");
          
      }
  }
     
      else{
          echo "Guide Can not be Added";
          header("refresh:2; url=sguides.php");
      }
  }
  else{
      echo "Fill up Guide Details related Fields";
  }
}
?>
<!-- 
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Add room</title>
</head>

<body>

    <form action="addguide.php" method="post">
        <label for="s_no">Serial Number:</label><br>
        <input type="number" name="s_no"><br>
        <label for="id">Guide ID:</label><br>
        <input type="number"  name="id"><br>
        <input type="submit" name="submit">
        <a href="guide_admin_dashboard.php">admin_dashboard</a>
    </form>
    

</body>
</html> -->


<!-- //*! -->



<!DOCTYPE html>
<html lang="en">

<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- <link rel="icon" href="../image/favicon.png" type="image/png"> -->
        <title>Add Room</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../css/bootstrap.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        
        <style type="text/css">
            .btn{
                margin-right: 15px;
            }

            body {
            background-color: lightgreen;
              }

              .card:hover{
     transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}

.navbar{
     font-size: 20px;
}
.navbar-brand{
     font-size: 20px; 
}

.navbar ul li a
            {
                text-decoration: none;
        text-align: center;
        font-size: 20px;
        color: white;
        font-family: sans-serif;
        
        display: inline-block;
       
        width: 160px;
       
        height: 50px;
        line-height: 30px;
        /* left: 30%; */
        right: -390px;
        text-align: center; 
          
         color: black;
         font-size: 20px; 
         position: relative; 
        font-family: sans-serif;
        text-transform: uppercase;
        font-weight: bold; 
        transform: translateX(-50%);
        
            }

        .navbar ul li a:hover{
            background: rgba(224, 33, 33, 0.9);
            /* transform: scale(1.05); */
  box-shadow: 0 10px 20px rgba(0,0,0,20), 0 4px 8px rgba(0,0,0,10); 
            
           
            }
        .navbar ul li a:hover {
            display: block;
            
            } 
        </style>
    </head>

<body>

<header class="header_area">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <a class="navbar-brand logo_h" href="../private.php"><img src="Logo.PNG" alt=""></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                        <ul class="nav navbar-nav menu_nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="../private.php">Home</a></li>
                        <li class="nav-item active"><a class="nav-link" href="guide_admin_dashboard.php">Back</a></li>
                        <li class="nav-item active"><a class="nav-link" href="../about.php">About Us</a></li>
                        <li class="nav-item active"><a class="nav-link" href="#footer">Contacts</a></li>
                        <li class="nav-item active"><a class="nav-link" href="../logout.php">Log out</a></li>

                        </ul>
                    </div> 
                </nav>
            </div>
        </header>
        <!--================Header Area Finish=================-->
    
        <br><br><br><br><br>






<!--         
    <form action="addroom.php" method="post">
        <label for="s_no">Serial Number:</label><br>
        <input type="number" name="s_no"><br>
        <label for="room_no">Room Number:</label><br>
        <input type="number"  name="room_no"><br>
       
        <input type="submit" name="submit">
        <a href="admin_dashboard.php">admin_dashboard</a>
    </form>
    




</body>
</html> -->
<!-- //!*  -->
<!-- <form action="addguide.php" method="post">
        <label for="s_no">Serial Number:</label><br>
        <input type="number" name="s_no"><br>
        <label for="id">Guide ID:</label><br>
        <input type="number"  name="id"><br>
        <input type="submit" name="submit">
        <a href="guide_admin_dashboard.php">admin_dashboard</a>
    </form> -->












<div class="row">
       	<div class="col-md-12">
       		<center><h3>Add Guide</h3></center>
       	</div>
       </div><br><br>
        <div class="row">
        	<div class="col-md-2"></div>
        	<div class="col-md-8">

        		<form action="addguide.php" method="post">
			<div class="form-group">
		    	<label for="s_no">Serial Number:</label>
		    	<input type="number" class="form-control" name="s_no" required="">
		  	</div>
			<div class="form-group">
		    	<label for="id">Guide ID:</label>
		    	<input type="number" class="form-control" name="id" required="">
		  	</div>
		  	
				<input type="submit" class="btn btn-warning" name="submit"> 
                <!-- <a href="admin_dashboard.php">admin_dashboard</a> -->
           
		</form>
        
        	</div>
        	<div class="col-md-2"></div>
        </div>
        <br><br><br><br><br><br>
        <!--================ start footer Area  =================-->	
        <footer class="bg-secondary text-center " id="footer">
    <!-- Grid container -->
    <div class="container p-4">
  
      <!-- Section: Social media -->
      <section class="mb-4">
        <!-- Facebook -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #3b5998" href="#!" role="button"><i class="fab fa-facebook-f"></i></a>
  
        <!-- Twitter -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #55acee" href="#!" role="button"><i class="fab fa-twitter"></i></a>
  
        <!-- Google -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #dd4b39" href="#!" role="button"><i class="fab fa-google"></i></a>
  
        <!-- Instagram -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #ac2bac" href="#!" role="button"><i class="fab fa-instagram"></i></a>
  
        <!-- Linkedin -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #0082ca" href="#!" role="button"><i class="fab fa-linkedin-in"></i></a>
        <!-- Github -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #333333" href="#!" role="button"><i class="fab fa-github"></i></a>
      </section>
      <!-- Section: Social media -->
  
  
      <!-- Section: Form -->
      <section class="">
        <form action="">
          <!--Grid row-->
          <div class="row d-flex justify-content-center">
            <!--Grid column-->
            <div class="col-auto">
              <p class="pt-2">
                <strong>Sign up</strong>
              </p>
            </div>
            <!--Grid column-->
  
            <!--Grid column-->
            <div class="col-md-5 col-12">
              <!-- Email input -->
              <div class="form-outline mb-4">
                <input type="email" id="form5Example2" class="form-control" />
                <label class="form-label" for="form5Example2">Email address</label>
              </div>
            </div>
            <!--Grid column-->
  
            <!--Grid column-->
            <div class="col-auto">
  
              <!-- Submit button -->
              <button type="submit" class="btn btn-danger mb-4">
                Subscribe
              </button>
            </div>
            <!--Grid column-->
          </div>
          <!--Grid row-->
        </form>
      </section>
      <!-- Section: Form -->
  
  
      <!-- Section: Text -->
      <section class="mb-4">
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt
          distinctio earum repellat quaerat voluptatibus placeat nam,
          commodi optio pariatur est quia magnam eum harum corrupti dicta,
          aliquam sequi voluptate quas.
        </p>
      </section>
      <!-- Section: Text -->
  
  
      <!-- Section: Links -->
      <section class="">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Contacts</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">www.facebook.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.instagram.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.twitter.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.github.com</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Contacts</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">www.whatsapp.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.telegram.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.youtube.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.messenger.com</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Services</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">Facebook Lite</a>
              </li>
              <li>
                <a href="#!" class="text-light">messenger light</a>
              </li>
              <li>
                <a href="#!" class="text-light">whatsapp lite</a>
              </li>
              <li>
                <a href="#!" class="text-light">pintrest</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">More</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">Race</a>
              </li>
              <li>
                <a href="#!" class="text-light">Ranks</a>
              </li>
              <li>
                <a href="#!" class="text-light">Favourites</a>
              </li>
              <li>
                <a href="#!" class="text-light">New</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </section>
      <!-- Section: Links -->
  
    </div>
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
      © 2020 Copyright:
      <!-- <a class="text-light" href="https://mdbootstrap.com/">MDBootstrap.com</a> -->
    </div>
    <!-- Copyright -->
    
  </footer>
    </body>
</html>
