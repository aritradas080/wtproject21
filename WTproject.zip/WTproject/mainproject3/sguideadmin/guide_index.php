<?php
    session_start();
    if(isset($_POST['admin_login'])){
        $connection = mysqli_connect("localhost","root","");
        $db = mysqli_select_db($connection,"app_users");
        $query = "select * from sgadmin where email = '$_POST[email]'";
        $query_run = mysqli_query($connection,$query);
        while($row = mysqli_fetch_assoc($query_run)){
            if($row['email'] == $_POST['email']){
                if($row['password'] == $_POST['password']){
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['email'] = $row['email'];
                    header("Location:guide_admin_dashboard.php");
                }
                else{
                    echo "<script>alert('Wrong Password...');</script>";
                }
            }
        }
    }
?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- <link rel="icon" href="../image/favicon.png" type="image/png"> -->
        <title>Royal Hotel</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../css/bootstrap.css">
        <!-- <link rel="stylesheet" href="../vendors/linericon/style.css"> -->
        <link rel="stylesheet" href="../css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="../vendors/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="../vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.css">
        <link rel="stylesheet" href="../vendors/nice-select/css/nice-select.css">
        <link rel="stylesheet" href="../vendors/owl-carousel/owl.carousel.min.css"> -->
        <!-- main css -->
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/responsive.css">
        <style type="text/css">
            .btn{
                margin-right: 15px;
            }

            body {
            background-color: lightsalmon;
              }
              .card:hover{
     transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0,0,0,20), 0 4px 8px rgba(0,0,0,10);
}

.navbar{
     font-size: 20px;
}
.navbar-brand{
     font-size: 20px; 
}

.navbar ul li a
            {
                text-decoration: none;
        text-align: center;
        font-size: 20px;
        color: white;
        font-family: sans-serif;
        
        display: inline-block;
       
        width: 160px;
       
        height: 50px;
        line-height: 30px;
        /* left: 30%; */
        right: -390px;
        text-align: center; 
          
         color: black;
         font-size: 20px; 
         position: relative; 
        font-family: sans-serif;
        text-transform: uppercase;
        font-weight: bold; 
        transform: translateX(-50%);
        
            }

        .navbar ul li a:hover{
            background: rgba(224, 33, 33, 0.9);
            /* transform: scale(1.05); */
  box-shadow: 0 10px 20px rgba(0,0,0,20), 0 4px 8px rgba(0,0,0,10); 
            
           
            }
        .navbar ul li a:hover {
            display: block;
            
            } 
            
            
        </style>
    </head>
    <body>
        <!--================Header Area =================-->
        <header class="header_area">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <a class="navbar-brand logo_h" href="../private.php"><img src="Logo.PNG" alt=""></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                        <ul class="nav navbar-nav menu_nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="../sylindex.html">Home</a></li>
                        <li class="nav-item active"><a class="nav-link" href="../sylindex.html">Back</a></li>
                        <li class="nav-item active"><a class="nav-link" href="../about.php">About Us</a></li>
                        <li class="nav-item active"><a class="nav-link" href="#footer">Contacts</a></li>
                        <li class="nav-item active"><a class="nav-link" href="../logout.php">Log out</a></li>
                            <!-- <li class="nav-item"><a class="nav-link" href="about.html">About us</a></li> -->
                            <!-- <li class="nav-item"><a class="nav-link" href="accomodation.html">Accomodation</a></li>
                            <li class="nav-item"><a class="nav-link" href="gallery.html">Gallery</a></li>
                            <li class="nav-item submenu dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog</a>
                                <ul class="dropdown-menu">
                                    <li class="nav-item"><a class="nav-link" href="blog.html">Blog</a></li>
                                    <li class="nav-item"><a class="nav-link" href="blog-single.html">Blog Details</a></li>
                                </ul>
                            </li> 
                            <li class="nav-item"><a class="nav-link" href="elements.html">Elemests</a></li>
                            <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li> -->
                        </ul>
                    </div> 
                </nav>
            </div>
        </header>
        <!--================Header Area Finish=================-->
    
        <br><br><br><br><br>
        <!--================Banner Area END =================-->
       <div class="row">
       	<div class="col-md-12">
       		<center><h3>Admin Login Page</h3></center>
       	</div>
       </div><br><br>
        <div class="row">
        	<div class="col-md-2"></div>
        	<div class="col-md-8">
        		<form action="" method="post">
			<div class="form-group">
		    	<label for="name">Email:</label>
		    	<input type="text" class="form-control" name="email" required="">
		  	</div>
			<div class="form-group">
		    	<label for="email">Password:</label>
		    	<input type="password" class="form-control" name="password" required="">
		  	</div>
		  	
				<button type="submit" class="btn btn-success" name="admin_login">Login</button>
		</form>
        
        	</div>
        	<div class="col-md-2"></div>
        </div>
        <br><br><br><br><br><br>
        <!--================ start footer Area  =================-->	
        <footer class="bg-secondary text-center " id="footer">
    <!-- Grid container -->
    <div class="container p-4">
  
      <!-- Section: Social media -->
      <section class="mb-4">
        <!-- Facebook -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #3b5998" href="#!" role="button"><i class="fab fa-facebook-f"></i></a>
  
        <!-- Twitter -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #55acee" href="#!" role="button"><i class="fab fa-twitter"></i></a>
  
        <!-- Google -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #dd4b39" href="#!" role="button"><i class="fab fa-google"></i></a>
  
        <!-- Instagram -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #ac2bac" href="#!" role="button"><i class="fab fa-instagram"></i></a>
  
        <!-- Linkedin -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #0082ca" href="#!" role="button"><i class="fab fa-linkedin-in"></i></a>
        <!-- Github -->
        <a class="btn btn-primary btn-floating m-1" style="background-color: #333333" href="#!" role="button"><i class="fab fa-github"></i></a>
      </section>
      <!-- Section: Social media -->
  
  
      <!-- Section: Form -->
      <section class="">
        <form action="">
          <!--Grid row-->
          <div class="row d-flex justify-content-center">
            <!--Grid column-->
            <div class="col-auto">
              <p class="pt-2">
                <strong>Sign up</strong>
              </p>
            </div>
            <!--Grid column-->
  
            <!--Grid column-->
            <div class="col-md-5 col-12">
              <!-- Email input -->
              <div class="form-outline mb-4">
                <input type="email" id="form5Example2" class="form-control" />
                <label class="form-label" for="form5Example2">Email address</label>
              </div>
            </div>
            <!--Grid column-->
  
            <!--Grid column-->
            <div class="col-auto">
  
              <!-- Submit button -->
              <button type="submit" class="btn btn-danger mb-4">
                Subscribe
              </button>
            </div>
            <!--Grid column-->
          </div>
          <!--Grid row-->
        </form>
      </section>
      <!-- Section: Form -->
  
  
      <!-- Section: Text -->
      <section class="mb-4">
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt
          distinctio earum repellat quaerat voluptatibus placeat nam,
          commodi optio pariatur est quia magnam eum harum corrupti dicta,
          aliquam sequi voluptate quas.
        </p>
      </section>
      <!-- Section: Text -->
  
  
      <!-- Section: Links -->
      <section class="">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Contacts</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">www.facebook.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.instagram.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.twitter.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.github.com</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Contacts</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">www.whatsapp.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.telegram.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.youtube.com</a>
              </li>
              <li>
                <a href="#!" class="text-light">www.messenger.com</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Services</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">Facebook Lite</a>
              </li>
              <li>
                <a href="#!" class="text-light">messenger light</a>
              </li>
              <li>
                <a href="#!" class="text-light">whatsapp lite</a>
              </li>
              <li>
                <a href="#!" class="text-light">pintrest</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">More</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="#!" class="text-light">Race</a>
              </li>
              <li>
                <a href="#!" class="text-light">Ranks</a>
              </li>
              <li>
                <a href="#!" class="text-light">Favourites</a>
              </li>
              <li>
                <a href="#!" class="text-light">New</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </section>
      <!-- Section: Links -->
  
    </div>
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
      © 2020 Copyright:
      <!-- <a class="text-light" href="https://mdbootstrap.com/">MDBootstrap.com</a> -->
    </div>
    <!-- Copyright -->
    
  </footer>
    </body>
</html>
