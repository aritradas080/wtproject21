<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="register.css">
   
</head>
<body>

<?php
if(session_status() >= 0){
    session_start();
    if(isset($_SESSION["uname"])){
        header("refresh: 0.5; url=private.php");
    }
}
?>

    <div class="wrapper">
        <div class="main">
            <h1>Create Account</h1>
            <form action="process.php" name="myform" onsubmit="return validateForm()" method="post">
                <p><input type="text" name="uname" placeholder="User Name" class="intpt"></p>
                <p><input type="number" name="uid" placeholder="ID" class="intpt"></p>
                <p><input type="number" name="age" placeholder="Age" class="intpt"></p>
                <p><input type="tel" id="phone" name="phone"  placeholder="Phone no." class="intpt"></p>
                <p><input type="email" name="email" placeholder="Email" class="intpt"></p>
                <p><input type="password" name="pass" placeholder="Password" class="intpt"></p>
                <p><input type="password" name="cpass" placeholder="Confirm password" class="intpt"></p>
                <div class="bott">
                <p><input type="submit" name="Register" value="Register" class="btn f1"></p>
                <!-- <p><input type="submit" name="Login" value="Login" class="btn f2" url="index.php"></p> -->
                </div>
            </form>
            <p><input type="submit" name="Login" value="Login" class="submitbtn" onclick="location.href='index.php';"></p>
        </div>
    </div>

    
    <script>

function validateForm() {
  let x = document.forms["myform"]["uname"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }

  let y = document.forms["myform"]["pass"].value;
  if (y == "") {
    alert("Provide a Password");
    return false;
  }

  let z = document.forms["myform"]["cpass"].value;
  if (z == "") {
    alert("Confirmation needed");
    return false;
  }

  let m = document.forms["myform"]["pass"].value;
      if (m.length < 8) {
    alert("Weak Password. Add at least 10 Characters");
    return false;
  }

  let n = document.forms["myform"]["email"].value;
      if (n == "") {
    alert("Give your Email Address");
    return false;
  }
  let o = document.forms["myform"]["phone"].value;
      if (o == "") {
    alert("Give your phone number");
    return false;
  }
}
    </script>
</body>
</html>