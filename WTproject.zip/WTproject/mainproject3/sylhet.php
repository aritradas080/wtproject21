<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sylhet</title>
</head>
<body bgcolor="#90EE90">
<h1 align="middle">Welcome to Sylhet</h1>
    <p align="center"><img src="s2.png" height="250" width="300" alt="">
    <img src="s1.png" height="250" width="300" alt=""></p>
    <h2 align="center">About Sylhet</h2>
    <h4 align="center">This ravishing city located at northeast of Bangladesh. Consisting of rich culture and significant archaeological sites, this city has vast amount of historic significance. The culture and traditions attract a lot of tourists each year.</h4>
    <br>
    <h2 align="middle">You prefer : </h1>
    <form action="sylhet.php" method="post">
        <div align="center"><input type="radio" id="night" name="media" value="night">
        <label for="night">Night Coach</label>
        <input type="radio" id="day" name="media" value="day">
        <label for="day">Day Coach</label>
        <br><br>
        <input type="submit" name ="submit"></div>
        <br>


        <?php
            if (isset($_POST["submit"])) 
             {
            $answer3 = $_POST['media'];


if ($answer3 == "night"){

        session_start();
        header("refresh: 1; url=syl_media_night.php");
    }

if ($answer3 == "day"){
        session_start();
        header("refresh: 1; url=syl_media_day.php");}


    }
?>
    <a href="places.php">Back</a>
</body>
</html>