<?php
if (isset($_POST["submit"])) {
    $uname = filter_var($_POST["uname"]);
        if (filter_var($uname)) {   
            $places= $_POST["places"];
            $medium = $_POST["medium"];
            $id= $_POST["id"];
            $conn = mysqli_connect('localhost', 'root', '','app_users');
            $sql="INSERT INTO travel_details(id, username, spot, medium) VALUES(0, '$uname', '$places', '$medium')";
            if (mysqli_query($conn, $sql)) {
                session_start();
                $_SESSION["uname"] = $_POST["uname"];
                echo "";
                echo "<br>";
                header("refresh: 4; url=departure.php");
    }
}

    else{
       echo 1;
    //    echo "Email format is not correct.";
       header("refresh: 2; url=places.php");
}
    }

    else {
        echo 2;
        // echo "Please make sure both password fields are same.";
        header("refresh: 2; url=places.php");
    }
    
    
        if (session_status()==PHP_SESSION_NONE){}
        header("location: places.php");



?>