<?php
 echo "natural";
?>