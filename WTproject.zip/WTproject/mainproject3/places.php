<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body bgcolor="#FFFF99">
<?php
    if(isset($_SESSION["uname"])){
        session_start();
    }
?>
<h2 align="middle">Available Places</h2>
<h3 align="center">Choose your tourist spot : </h3>
    <form action="places.php" method="post">

        <div align="center"><input type="radio" id="sundarban" name="places" value="sundarban">
        <label for="sundarban">Sundarbans</label>
        <input type="radio" id="cox's bazar" name="places" value="COX's BAZAR">
        <label for="cox's bazar">Cox's Bazar</label>
        <input type="radio" id="rangamati" name="places" value="RANGAMATI">
        <label for="rangamati">Rangamati</label>
        <input type="radio" id="sylhet" name="places" value="SYLHET">
        <label for="sylhet">Sylhet</label><br>
        <br>
        <input type="submit" name="submit"></div>
        <p align=center><img src="phototourist (2).jpg" width="450" height="350" alt="">
        <img src="Cartoon_tourist.jpg" width="450" height="350" alt=""></p>


<?php
            if (isset($_POST["submit"])) 
             {
            $answer1 = $_POST['places'];


if ($answer1 == "sundarban"){

        session_start();
        header("refresh: 2; url=sundarbans.php");}

if ($answer1 == "COX's BAZAR"){
        session_start();
        header("refresh: 2; url=coxsbazar.php");}

if ($answer1 == "RANGAMATI"){
    session_start();
    header("refresh: 2; url=rangamati.php");}

if ($answer1 == "SYLHET"){
    session_start();
    header("refresh: 2; url=sylhet.php");}


    }
  

    if (isset($_POST["submit"])) {
            
                $uname=$_SESSION["uname"];
                

                $conn = mysqli_connect('localhost', 'root', '','app_users');
                $sql="INSERT INTO travel_details(username, spot) VALUES('$uname', '$answer1')";
                mysqli_query($conn, $sql);
            }
        
?>

        <p align=middle><a href="private.php">Go Back</a></p>
    </form>
</body>
</html>