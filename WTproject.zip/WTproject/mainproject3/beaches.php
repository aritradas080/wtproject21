<?php
 echo "beaches";
?>