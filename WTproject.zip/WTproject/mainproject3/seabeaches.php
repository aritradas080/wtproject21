<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hills</title>
</head>
<body>
<?php
    if(isset($_SESSION["uname"])){
        session_start();
    }
?>
<h2 align="middle">Welcome To the Journey of Sea Beaches :</h2>
<form action="seabeaches.php" method="post">
<!-- selecting places with hills -->
<p align="middle">
    <text>Choose Your Place</text><br>
<label for="seabeaches"></label>
<select name="seabeaches" id="seabeaches">
<section>
  <optgroup label="Choose">
    <option value="kuakata">Kuakata</option>
    <option value="coxsbazar">CoxsBazar</option>
    <option value="saintmartins">SaintMartins</option>
    
  </optgroup>
</section>
</select>
</p>

<!-- You want to go at night or day -->
<p align="middle">
    <text>Choose Your Time</text><br>
<label for="coach"></label>
<select name="coach" id="coach">
<section>
  <optgroup label="Choose">
    <option value="day">DayCoach</option>
    <option value="night">NightCoach</option>
</optgroup>
</section>
</select>
</p>

<!-- selecting mediums for Kuakata (day) -->
<p align="left">
    <text>Choose Your Medium for Kuakata (Day Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
    <option value="royalkuaday">RoyalCoach-Day</option>
    <option value="tubakuaday">TubaLine-Day</option>
   
  </optgroup>
</section>
</select>
</p>
<!-- selecting mediums for Kuakata (night) -->
<p align="left">
    <text>Choose Your Medium for Kuakata (Night Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
  <option value="royalkuanight">RoyalCoach-Night</option>
    <option value="tubakuanight">TubaLine-Night</option>
  </optgroup>
</section>
</select>
</p>
<!-- selecting mediums for Cox's Bazar (day) -->
<p align="left">
    <text>Choose Your Medium for Cox's Bazar (Day Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
    <option value="greencobday">GreenLine-Day</option>
    <option value="saintcobday">SaintmartinsTravels-Day</option>
  </optgroup>
</section>
</select>
</p>
<!-- selecting mediums for Cox's Bazar (night) -->
<p align="left">
    <text>Choose Your Medium for Cox's Bazar (Night Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
  <option value="greencobnight">GreenLine-Night</option>
    <option value="saintcobday">SaintmartinsTravels-Night</option>
  </optgroup>
</section>
</select>
</p>
<!-- selecting mediums for SaintMartins (day) -->
<p align="left">
    <text>Choose Your Medium for Saint Martins (Day Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
    <option value="eagleday">Eagle-Day</option>
    <option value="falconday">Falcon-Day</option>
  </optgroup>
</section>
</select>
</p>
<!-- selecting mediums for Cox's Bazar (night) -->
<p align="left">
    <text>Choose Your Medium for Saint Martins (Night Coach)</text><br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
  <option value="eaglenight">Eagle-Night</option>
    <option value="falconnight">Falcon-Night</option>
  </optgroup>
</section>
</select>
</p>
<input type="submit" name="submit"></div>
</form>
<!-- <a href="seabeachesticket.php">Go To Next Page for More Details</a> -->

<?php
            if (isset($_POST["submit"])) 
             {
            $answer1 = $_POST['seabeaches'];


if ($answer1 == "kuakata"){

        session_start();
        header("refresh: 2; url=seabeachesticket.php");}

if ($answer1 == "coxsbazar"){
        session_start();
        header("refresh: 2; url=coxsticket.php");
      }

if ($answer1 == "saintmartins"){
        session_start();
        header("refresh: 2; url=sainticket.php");
      }      

// if ($answer1 == "RANGAMATI"){
//     session_start();
//     header("refresh: 2; url=rangamati.php");}

// if ($answer1 == "SYLHET"){
//     session_start();
//     header("refresh: 2; url=sylhet.php");}


//    
 }

 ?>
</body>
</html>