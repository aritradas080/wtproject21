<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body bgcolor="#0BB5FF">
<h1 align="middle">Welcome to Cox's Bazar</h1>
    <p align="center"><img src="c1.png" height="250" width="300" alt="">
    <img src="c2.png" height="250" width="300" alt=""></p>
    <h2 align="center">About Cox's Bazar</h2>
    <h4 align="center">Mostly known for being the longest sea beach in the world, cox’s bazar in one of the most popular tourist spots. Located at southeastern Bangladesh in the city Chittagong, it is must see tourist spot in Bangladesh.</h4>
    <br>

    <h2 align="middle">You prefer : </h1>
    <form action="coxsbazar.php" method="post">
        <div align="center"><input type="radio" id="night" name="media" value="night">
        <label for="night">Night Coach</label>
        <input type="radio" id="day" name="media" value="day">
        <label for="day">Day Coach</label>
        <br><br>
        <input type="submit" name ="submit"></div>
        <br>


        <?php
            if (isset($_POST["submit"])) 
             {
            $answer5 = $_POST['media'];


if ($answer5 == "night"){

        session_start();
        header("refresh: 1; url=cb_media_night.php");
    }

if ($answer5 == "day"){
        session_start();
        header("refresh: 1; url=cb_media_day.php");}


    }
?>
    <a href="places.php">Back</a>
    </body>
</html>