<?php
if (isset($_POST["Register"])) {
    if(strlen($_POST["pass"])>10){

    
    if (($_POST["pass"]) == ($_POST["cpass"])) {
        $uname = filter_var($_POST["uname"]);
        $email = filter_var($_POST["email"]);
        if ($email) { 
         function checkemail($email) {
         return (preg_match("/^([a-z\+_\-]+)(\.[a-z\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $email)) ? FALSE : TRUE;
   }

   if(checkemail("$email")){
      echo "Invalid email address.";
      header("refresh: 2; url=registration.php");
      
   }
   else{
      echo "Valid email address.";
            
            $email= $_POST["email"];
            $pass = $_POST["pass"];
            $pno= $_POST["phone"];
            $age = $_POST["age"];
            $conn = mysqli_connect('localhost', 'root', '','app_users');
            $sql="INSERT INTO records(id, username, email, password, phone_no, age) VALUES(0, '$uname', '$email', '$pass', $pno, $age)";
            if (mysqli_query($conn, $sql)) {
                session_start();
                $_SESSION["uname"] = $_POST["uname"];
                echo "Registration  Accepted";
                echo "<br>";
                header("refresh: 4; url=private.php");
    }
}
        }
    else{
       
       echo "Email field is empty. Provide your Email.";
       header("refresh: 2; url=registration.php");
}
}
    else {
        
        echo "Please make sure both password fields are same.";
        header("refresh: 2; url=registration.php");
    }
}
else {
    echo "Weak Password";
    header("refresh: 2; url=registration.php");
}
}

else{
    
    if (session_status()==PHP_SESSION_NONE){}
    header("location: index.php");
}
?>