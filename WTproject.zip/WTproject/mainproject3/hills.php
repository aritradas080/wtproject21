<?php
session_start();
if(isset($_SESSION["uname"])){
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>

    <!-- <link rel="stylesheet" href="hillscss.css"> -->
  
    <title>hills</title>
    <style type="text/css">
            .btn{
                margin-right: 30px;
            }
            /* .submit-btn{
              font-size: 40px;
            } */


            /* .navdemo{
                right: 30%;
            } */
            
            /* body {
            background-color: lightgreen;
              } */
              .contact-form{
        background-size: cover;
        width: 540px;
        height: 400px;
        border-radius: 5px;
        background:greenyellow;
        padding:20px;
        position: absolute;
        top: 30%; 
        left:-50px;
        transform: translateX(1200px);
     
      }
      
              .submit-btn:hover{
     transform: scale(1.05);
  box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
}
            
        </style>
<link rel="stylesheet" href="hillscss.css">


    </script> 
  </head>

  <body>

    <div class="slideshow">
        <div class="slideshow-item">
        <img src="Jaflong_Sylhet.jpg" alt="">
        <div class="slideshow-item-text">
        <h5>Jaflong,Sylhet</h5>
        <p>Jaflong is a hill station and tourist destination in the Division of Sylhet, Bangladesh.
        It is located in Gowainghat Upazila of Sylhet District and situated at the border between Bangladesh and the 
        Indian state of Meghalaya, overshadowed by subtropical mountains and rainforests. It is known for its stone 
        collections and is home of the Khasi tribe</p>
        </div>
        </div>

        <div class="slideshow-item">
        <img src="Kaptai_Lake_Rangamati.jpg" alt="">
        <div class="slideshow-item-text">
        <h5>Kaptai Lake,Rangamati</h5>
        <p>Kaptai Lake is the largest lake in Bangladesh.[1] It is located in the Kaptai Upazila under Rangamati District of Chittagong Division. 
        The lake was created as a result of building the Kaptai Dam on the Karnaphuli River, as part of the Karnaphuli Hydro-electric project. 
        Kaptai Lake's average depth is 100 feet (30 m) and maximum depth is 490 feet (150 m).</p>
        </div>
        </div>

        <div class="slideshow-item">
        <img src="NilGiri_Bandarban.jpg" alt="">
        <div class="slideshow-item-text">
        <h5>Nilgiri,Bandarban</h5>
        <p>Nilgiri is a collection of multiple variable sizes hill area in Bandarban. Bandarban itself is a hill district in Banglades. 
        The mountains with Covering trees look very beautiful from Nilgiri.The journey with locally called Chader gari (Moon Car) is very much enjoyble and full of thrills. 
        The Nilgiri tourist area is very clean and is under supervision of Bangladesh Army.Clean wash rooms and cafeteria also availabl.</p>
        </div>
        </div>
        <div class="slideshow-item">
        <img src="Patenga_seabeach_chittagong.jpg" alt="">
        <div class="slideshow-item-text">
        <h5>Patenga Sea Beach, Chittagong</h5>
        <p>Patenga is a sea beach of the Bay of Bengal, located 14 kilometres (8.7 mi) south from the port city of Chattogram, Bangladesh. 
        It is near to the mouth of the Karnaphuli River. The beach is very close to the Bangladesh Naval Academy of the Bangladesh Navy and Shah Amanat International Airport.</p>


        </div>
        </div>
</div>
<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->


<div class="wrapper">
<ul>
<div class="logo">
          <a href="private.php">
            <img src="Logo.PNG" alt="">
          </a>
        </div>
<li><a href="private.php">Back</a></li>
<li><a href="private.php">Home</a></li>
<li><a href="about.php">About us</a></li>
<li><a href="logout.php">Logout</a></li>
<!-- <li>Home</li> -->
  <!---------------------------------------------------------- Work Needed Here---------------------------------------------------------->

</ul>
</div>


    <div class="contact-form">
     <form action="hills.php" method="post">
        <div class="form-control">



<label for="hills"></label>
<select name="hills" id="hills">
<section>
  <optgroup label="Choose">
    <option value="sylhet">Sylhet</option>
    <option value="chittagong">Chittagong</option>
    <option value="bandarban">Bandarban</option>
    <option value="rangamati">Rangamati</option>
  </optgroup>
</section>
</select>
                <br>
               <label for="coach"></label>
<select name="coach" id="coach">
<section>
  <optgroup label="Choose">
    <option value="day">DayCoach</option>
    <option value="night">NightCoach</option>
</optgroup>
</section>
</select>

<br>
<label for="mediums"></label>
<select name="mediums" id="mediums">
<section>
  <optgroup label="Choose">
    <option value="greenlinesylday">GreenLine</option>
    <option value="asialinesylday">AsiaLine</option>
  <option value="greenlinesylday">Ena</option>
    <option value="asialinesylday">Pahartoli</option>
   
  </optgroup>
</section>
</select>
<input type="submit" value="Let's Go!!!" name="submit" id="submit-btn" class="submit-btn">
</form>
</div>

<?php
            if (isset($_POST["submit"])) 
             {
            $answer1 = $_POST['hills'];


if ($answer1 == "sylhet"){

        // session_start();
        // header("refresh: 2; url=sylticket.php");
        // header("Location: sylticket.php");
        $URL="sylticket.php";
        echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
        echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
      
      }

if ($answer1 == "rangamati"){
        // session_start();
        // header("refresh: 2; url=ranticket.php");
        // header("Location: ranticket.php");
        $URL="ranticket.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
  echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
      }

// if ($answer1 == "RANGAMATI"){
//     session_start();
//     header("refresh: 2; url=rangamati.php");}

// if ($answer1 == "SYLHET"){
//     session_start();
//     header("refresh: 2; url=sylhet.php");}


// 
 }

 if (isset($_POST["submit"])) {
   
  // $_SESSION["uname"]          
  $uname=$_SESSION["uname"];
  $answer10 = $_POST['hills'];
  $answer20 = $_POST['coach'];
  $answer30= $_POST['mediums'];
  

  $conn = mysqli_connect('localhost', 'root', '','app_users');
  $sql="INSERT INTO tour_details_new (username, place, coach, medium) VALUES('$uname', '$answer10', '$answer20', '$answer30')";
  mysqli_query($conn, $sql);
}

  
?>

</div>
</div>


</body>
</html>
